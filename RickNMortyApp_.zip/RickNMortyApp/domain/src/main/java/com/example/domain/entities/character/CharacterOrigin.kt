package com.example.domain.entities.character


data class CharacterOrigin(
    val name: String? = null,
    val url: String? = null
)
