package com.example.domain.entities.character


data class CharacterLocation(
    val name: String? = null,
    val url: String? = null
)
