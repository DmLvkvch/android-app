package com.example.data

import org.junit.jupiter.api.Test


class ExampleUnitTest {
    @Test
    fun test1() {

    }
}